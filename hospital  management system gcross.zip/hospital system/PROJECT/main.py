from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_login import UserMixin, login_user, logout_user, LoginManager, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
# from flask_mail import Mail
import json
import os
from datetime import datetime, date
from urllib.parse import quote_plus
import pymysql
from sqlalchemy.dialects import registry
from flask_sqlalchemy import SQLAlchemy

# Allow code expecting MySQLdb to work via PyMySQL
pymysql.install_as_MySQLdb()

# Ensure SQLAlchemy dialect alias maps mysqldb -> pymysql
registry.register("mysql.mysqldb", "sqlalchemy.dialects.mysql.pymysql", "MySQLDialect_pymysql")
# Also handle bare 'mysqldb' (without the mysql. prefix)
registry.register("mysqldb", "sqlalchemy.dialects.mysql.pymysql", "MySQLDialect_pymysql")



# MY db connection
local_server= True
app = Flask(__name__)
app.secret_key='hmsprojects'


# this is for getting unique user access
login_manager=LoginManager(app)
login_manager.login_view='login'

# SMTP MAIL SERVER SETTINGS

# app.config.update(
#     MAIL_SERVER='smtp.gmail.com',
#     MAIL_PORT='465',
#     MAIL_USE_SSL=True,
#     MAIL_USERNAME="add your gmail-id",
#     MAIL_PASSWORD="add your gmail-password"
# )
# mail = Mail(app)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))




# app.config['SQLALCHEMY_DATABASE_URL']='mysql://username:password@localhost/databas_table_name'
# Prefer environment variables; falls back to local defaults
db_user = os.getenv('DB_USER', 'root')
db_password = os.getenv('DB_PASSWORD', '')
db_host = os.getenv('DB_HOST', 'localhost')
db_name = os.getenv('DB_NAME', 'attendence')
encoded_password = quote_plus(db_password)
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{db_user}:{encoded_password}@{db_host}/{db_name}"
# Normalize any accidental mysqldb or bare mysql URIs to pymysql
uri = app.config.get('SQLALCHEMY_DATABASE_URI', '')
if uri.startswith('mysql://'):
    uri = uri.replace('mysql://', 'mysql+pymysql://', 1)
if uri.startswith('mysql+mysqldb://'):
    uri = uri.replace('mysql+mysqldb://', 'mysql+pymysql://', 1)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/mini db'
# Basic debug of chosen driver (masked)
try:
    safe_uri = uri.replace(db_password, '***') if db_password else uri
    print(f"Using SQLAlchemy URI: {safe_uri}")
except Exception:
    pass
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# Improve connection resiliency
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
}


# Initialize SQLAlchemy with the Flask app so `db` is available for model definitions
db = SQLAlchemy(app)




# here we will create db models that is tables
class Test(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(100))
    email=db.Column(db.String(100))

class User(UserMixin,db.Model):
    id=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(50))
    usertype=db.Column(db.String(50))
    email=db.Column(db.String(50),unique=True)
    # Use SQLAlchemy String type via `db.String` instead of sqlite3's dbapi2
    password=db.Column(db.String(1000))

class Patients(db.Model):
    pid=db.Column(db.Integer,primary_key=True)
    email=db.Column(db.String(50))
    name=db.Column(db.String(50))
    gender=db.Column(db.String(50))
    slot=db.Column(db.String(50))
    disease=db.Column(db.String(50))
    time=db.Column(db.String(50),nullable=False)
    date=db.Column(db.String(50),nullable=False)
    dept=db.Column(db.String(50))
    number=db.Column(db.String(50))

class Doctors(db.Model):
    did=db.Column(db.Integer,primary_key=True)
    email=db.Column(db.String(50))
    doctorname=db.Column(db.String(50))
    dept=db.Column(db.String(50))

class Trigr(db.Model):
    tid=db.Column(db.Integer,primary_key=True)
    pid=db.Column(db.Integer)
    email=db.Column(db.String(50))
    name=db.Column(db.String(50))
    action=db.Column(db.String(50))
    timestamp=db.Column(db.String(50))


# Ensure tables exist at startup (runs once when app starts)
try:
    with app.app_context():
        db.create_all()
except Exception as e:
    # Avoid crashing if DB is temporarily unavailable; test via /test route
    print(f"Database initialization error: {e}")





# here we will pass endpoints and run the fuction
@app.route('/')
def index():
    return render_template('index.html')
    


@app.route('/doctors',methods=['POST','GET'])
def doctors():

    if request.method=="POST":

        email=request.form.get('email')
        doctorname=request.form.get('doctorname')
        dept=request.form.get('dept')

        # query=db.engine.execute(f"INSERT INTO `doctors` (`email`,`doctorname`,`dept`) VALUES ('{email}','{doctorname}','{dept}')")
        query=Doctors(email=email,doctorname=doctorname,dept=dept)
        db.session.add(query)
        db.session.commit()
        flash("Information is Stored","primary")

    return render_template('doctor.html')



@app.route('/patients',methods=['POST','GET'])
@login_required
def patient():
    # doct=db.engine.execute("SELECT * FROM `doctors`")
    doct=Doctors.query.all()

    if request.method=="POST":
        email=request.form.get('email')
        name=request.form.get('name')
        gender=request.form.get('gender')
        slot=request.form.get('slot')
        disease=request.form.get('disease')
        time=request.form.get('time')
        date_str=request.form.get('date')
        dept=request.form.get('dept')
        number=request.form.get('number')
        # subject="HOSPITAL MANAGEMENT SYSTEM"
        
        # Date validation
        if not date_str:
            flash("Please choose a date", "warning")
            return render_template('patient.html',doct=doct)
        
        try:
            selected_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            today = date.today()
            days_difference = (selected_date - today).days
            
            if days_difference < 0:
                flash("Please choose a date that is not in the past", "danger")
                return render_template('patient.html',doct=doct)
            
            if days_difference > 4:
                flash("Please choose a date within the next 4 days", "danger")
                return render_template('patient.html',doct=doct)
        except ValueError:
            flash("Please choose a valid date", "danger")
            return render_template('patient.html',doct=doct)
        
        # Time validation
        if not time:
            flash("Please choose a time", "warning")
            return render_template('patient.html',doct=doct)
        
        # Slot validation
        if not slot:
            flash("Please choose a slot", "warning")
            return render_template('patient.html',doct=doct)
        
        try:
            # Parse time - support both 12-hour (with AM/PM) and 24-hour format
            time_upper = time.strip().upper()
            selected_time = None
            
            # Try parsing 12-hour format first (e.g., "9:30 AM", "5:00 PM")
            try:
                selected_time = datetime.strptime(time_upper, '%I:%M %p').time()
            except ValueError:
                # Try parsing 12-hour format without space (e.g., "9:30AM", "5:00PM")
                try:
                    selected_time = datetime.strptime(time_upper, '%I:%M%p').time()
                except ValueError:
                    # Fall back to 24-hour format (e.g., "09:30", "17:00")
                    selected_time = datetime.strptime(time, '%H:%M').time()
            
            current_datetime = datetime.now()
            current_time = current_datetime.time()
            
            # Slot-based time validation
            slot_lower = slot.lower()
            time_hour = selected_time.hour
            time_minute = selected_time.minute
            
            if 'morning' in slot_lower:
                # Morning slot: time should be before 12 PM (before 12:00)
                if time_hour >= 12:
                    flash("For morning slot, please choose a time before 12 PM", "danger")
                    return render_template('patient.html',doct=doct)
            elif 'evening' in slot_lower:
                # Evening slot: time should be between 5 PM (17:00) to 8 PM (20:00)
                if time_hour < 17 or time_hour >= 20:
                    flash("For evening slot, please choose a time between 5 PM to 8 PM", "danger")
                    return render_template('patient.html',doct=doct)
            elif 'night' in slot_lower:
                # Night slot: time should be between 8 PM (20:00) to 10 PM (22:00)
                if time_hour < 20 or time_hour >= 22:
                    flash("For night slot, please choose a time between 8 PM to 10 PM", "danger")
                    return render_template('patient.html',doct=doct)
            
            # Check if time is after 10 PM (22:00) - general validation
            if selected_time.hour >= 22:
                flash("Hospital is closed", "danger")
                return render_template('patient.html',doct=doct)
            
            # If selected date is today, check if time is in the past
            if days_difference == 0:
                if selected_time <= current_time:
                    flash("Please choose a time that is not in the past", "danger")
                    return render_template('patient.html',doct=doct)
            
            # Convert to 12-hour format for storage (optional - you can keep 24-hour in DB)
            # Format: "HH:MM AM/PM"
            time_12hr = selected_time.strftime('%I:%M %p')
            time = time_12hr  # Store in 12-hour format
        except ValueError:
            flash("Please choose a valid time format (e.g., 9:30 AM or 09:30)", "danger")
            return render_template('patient.html',doct=doct)
        
        if len(number)<10 or len(number)>10:
            flash("Please give 10 digit number")
            return render_template('patient.html',doct=doct)
  

        # query=db.engine.execute(f"INSERT INTO `patients` (`email`,`name`,	`gender`,`slot`,`disease`,`time`,`date`,`dept`,`number`) VALUES ('{email}','{name}','{gender}','{slot}','{disease}','{time}','{date_str}','{dept}','{number}')")
        query=Patients(email=email,name=name,gender=gender,slot=slot,disease=disease,time=time,date=date_str,dept=dept,number=number)
        db.session.add(query)
        db.session.commit()
        
        # mail starts from here

        # mail.send_message(subject, sender=params['gmail-user'], recipients=[email],body=f"YOUR bOOKING IS CONFIRMED THANKS FOR CHOOSING US \nYour Entered Details are :\nName: {name}\nSlot: {slot}")



        flash("Booking Confirmed","info")


    return render_template('patient.html',doct=doct)


@app.route('/bookings')
@login_required
def bookings(): 
    em=current_user.email
    if current_user.usertype=="Doctor":
        # query=db.engine.execute(f"SELECT * FROM `patients`")
        query = Patients.query.all()
        return render_template('booking.html', query=query)
    else:
        # query=db.engine.execute(f"SELECT * FROM `patients` WHERE email='{em}'")
        query = Patients.query.filter_by(email=em).all()
        return render_template('booking.html', query=query)
    


@app.route("/edit/<string:pid>",methods=['POST','GET'])
@login_required
def edit(pid):    
    if request.method=="POST":
        email=request.form.get('email')
        name=request.form.get('name')
        gender=request.form.get('gender')
        slot=request.form.get('slot')
        disease=request.form.get('disease')
        time=request.form.get('time')
        date_str=request.form.get('date')
        dept=request.form.get('dept')
        number=request.form.get('number')
        
        # Date validation
        if not date_str:
            flash("Please choose a date", "warning")
            posts=Patients.query.filter_by(pid=pid).first()
            return render_template('edit.html',posts=posts)
        
        try:
            selected_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            today = date.today()
            days_difference = (selected_date - today).days
            
            if days_difference < 0:
                flash("Please choose a date that is not in the past", "danger")
                posts=Patients.query.filter_by(pid=pid).first()
                return render_template('edit.html',posts=posts)
            
            if days_difference > 4:
                flash("Please choose a date within the next 4 days", "danger")
                posts=Patients.query.filter_by(pid=pid).first()
                return render_template('edit.html',posts=posts)
        except ValueError:
            flash("Please choose a valid date", "danger")
            posts=Patients.query.filter_by(pid=pid).first()
            return render_template('edit.html',posts=posts)
        
        # Time validation
        if not time:
            flash("Please choose a time", "warning")
            posts=Patients.query.filter_by(pid=pid).first()
            return render_template('edit.html',posts=posts)
        
        if not slot:
            flash("Please choose a slot", "warning")
            posts=Patients.query.filter_by(pid=pid).first()
            return render_template('edit.html',posts=posts)
        
        try:
            # Parse time - support both 12-hour (with AM/PM) and 24-hour format
            time_upper = time.strip().upper()
            selected_time = None
            
            # Try parsing 12-hour format first (e.g., "9:30 AM", "5:00 PM")
            try:
                selected_time = datetime.strptime(time_upper, '%I:%M %p').time()
            except ValueError:
                # Try parsing 12-hour format without space (e.g., "9:30AM", "5:00PM")
                try:
                    selected_time = datetime.strptime(time_upper, '%I:%M%p').time()
                except ValueError:
                    # Fall back to 24-hour format (e.g., "09:30", "17:00")
                    selected_time = datetime.strptime(time, '%H:%M').time()
            
            current_datetime = datetime.now()
            current_time = current_datetime.time()
            
            # Slot-based time validation
            slot_lower = slot.lower()
            time_hour = selected_time.hour
            
            if 'morning' in slot_lower:
                if time_hour >= 12:
                    flash("For morning slot, please choose a time before 12 PM", "danger")
                    posts=Patients.query.filter_by(pid=pid).first()
                    return render_template('edit.html',posts=posts)
            elif 'evening' in slot_lower:
                if time_hour < 17 or time_hour >= 20:
                    flash("For evening slot, please choose a time between 5 PM to 8 PM", "danger")
                    posts=Patients.query.filter_by(pid=pid).first()
                    return render_template('edit.html',posts=posts)
            elif 'night' in slot_lower:
                if time_hour < 20 or time_hour >= 22:
                    flash("For night slot, please choose a time between 8 PM to 10 PM", "danger")
                    posts=Patients.query.filter_by(pid=pid).first()
                    return render_template('edit.html',posts=posts)
            
            if selected_time.hour >= 22:
                flash("Hospital is closed", "danger")
                posts=Patients.query.filter_by(pid=pid).first()
                return render_template('edit.html',posts=posts)
            
            if days_difference == 0:
                if selected_time <= current_time:
                    flash("Please choose a time that is not in the past", "danger")
                    posts=Patients.query.filter_by(pid=pid).first()
                    return render_template('edit.html',posts=posts)
            
            # Convert to 12-hour format for storage
            time_12hr = selected_time.strftime('%I:%M %p')
            time = time_12hr
        except ValueError:
            flash("Please choose a valid time format (e.g., 9:30 AM or 09:30)", "danger")
            posts=Patients.query.filter_by(pid=pid).first()
            return render_template('edit.html',posts=posts)
        
        # db.engine.execute(f"UPDATE `patients` SET `email` = '{email}', `name` = '{name}', `gender` = '{gender}', `slot` = '{slot}', `disease` = '{disease}', `time` = '{time}', `date` = '{date_str}', `dept` = '{dept}', `number` = '{number}' WHERE `patients`.`pid` = {pid}")
        post=Patients.query.filter_by(pid=pid).first()
        post.email=email
        post.name=name
        post.gender=gender
        post.slot=slot
        post.disease=disease
        post.time=time
        post.date=date_str
        post.dept=dept
        post.number=number
        db.session.commit()

        flash("Slot is Updates","success")
        return redirect('/bookings')
        
    posts=Patients.query.filter_by(pid=pid).first()
    return render_template('edit.html',posts=posts)


@app.route("/delete/<string:pid>",methods=['POST','GET'])
@login_required
def delete(pid):
    # db.engine.execute(f"DELETE FROM `patients` WHERE `patients`.`pid`={pid}")
    query=Patients.query.filter_by(pid=pid).first()
    db.session.delete(query)
    db.session.commit()
    flash("Slot Deleted Successful","danger")
    return redirect('/bookings')



@app.route('/signup',methods=['POST','GET'])
def signup():
    if request.method == "POST":
        username=request.form.get('username')
        usertype=request.form.get('usertype')
        email=request.form.get('email')
        password=request.form.get('password')
        user=User.query.filter_by(email=email).first()
        if user:
            flash("Email Already Exist","warning")
            return render_template('signup.html')

        # Hash the password before storing
        encpassword = generate_password_hash(password)
        myquery = User(username=username, usertype=usertype, email=email, password=encpassword)
        db.session.add(myquery)
        db.session.commit()
        flash("Signup Success. Please login.", "success")
        return redirect(url_for('login'))

          

    return render_template('signup.html')

@app.route('/login',methods=['POST','GET'])
def login():
    if request.method == "POST":
        email=request.form.get('email')
        password=request.form.get('password')
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            flash("Login Success","primary")
            return redirect(url_for('index'))
        else:
            flash("Invalid credentials","danger")
            return render_template('login.html')





    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logout SuccessFul","warning")
    return redirect(url_for('login'))



@app.route('/test')
def test():
    try:
        Test.query.all()
        return 'My database is Connected'
    except:
        return 'My db is not Connected'
    

@app.route('/details')
@login_required
def details():
    posts=Trigr.query.all()
    # posts=db.engine.execute("SELECT * FROM `trigr`")
    return render_template('trigers.html',posts=posts)


@app.route('/search',methods=['POST','GET'])
@login_required
def search():
    if request.method=="POST":
        query=request.form.get('search')
        dept=Doctors.query.filter_by(dept=query).first()
        name=Doctors.query.filter_by(doctorname=query).first()
        if name:

            flash("Doctor is Available","info")
        else:

            flash("Doctor is Not Available","danger")
    return render_template('index.html')






if __name__ == '__main__':
    app.run(debug=True)

